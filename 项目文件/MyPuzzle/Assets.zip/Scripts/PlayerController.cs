﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    public GameController gamer;
    private Vector3 MouseLocation;
    private RaycastHit2D hit;
    private Transform tr;
    private Vector3 EmptyLocation;
    private Vector3 temp;
    private bool IsSet;
    private bool IsViewer;
    private int work; 
    private Text bushu;
    private Text viewtext;
    private Image view;

    // Use this for initialization
    void Start () {
        IsSet = false;
        IsViewer = false;
        work = 0;
        bushu = GameObject.Find("Canvas/Bushu").GetComponent<Text>();
        view = GameObject.Find("Canvas/Picture").GetComponent<Image>();
        viewtext = GameObject.Find("Canvas/View/Text").GetComponent<Text>();
    }
	
	// Update is called once per frame
	void Update () {
        if (!gamer.OnPrepare && !gamer.IsFinish && !IsViewer)
        {
            if (!IsSet)
            {
                EmptyLocation = new Vector3(2 * gamer.kl - 3, 2 - 2 * gamer.kh, 0);
                IsSet = true;
            }
            if (Input.GetMouseButtonDown(0))
            {
                MouseLocation = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                hit = Physics2D.Raycast(new Vector2(MouseLocation.x, MouseLocation.y), new Vector2(MouseLocation.x, MouseLocation.y), 0.1f);
                if (hit.collider != null)
                {
                    tr = hit.collider.GetComponent<Transform>();
                    if (System.Math.Pow(tr.position.x - EmptyLocation.x, 2) + System.Math.Pow(tr.position.y - EmptyLocation.y, 2) == 4)
                    {
                        temp = EmptyLocation;
                        EmptyLocation = tr.position;
                        tr.position = temp;
                        work++;
                        bushu.text = "步数：" + work;
                    }
                }
            }

        }
    }

    public void ToReset()
    {
        gamer.ReSet();
        work = 0;
        bushu.text = "步数：" + work;
        IsSet = false;
    }

    public void ToView()
    {
        if (!IsViewer)
        {
            view.enabled = true;
            viewtext.text = "Close";
            IsViewer = true;
        }
        else
        {
            view.enabled = false;
            viewtext.text = "View";
            IsViewer = false;
        }

    }

    

}
