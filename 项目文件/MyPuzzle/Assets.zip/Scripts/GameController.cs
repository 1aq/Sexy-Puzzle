﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class GameController : MonoBehaviour {

    

    private Renderer R0;
    private Renderer R1;
    private Renderer R2;
    private Renderer R3;
    private Renderer R4;
    private Renderer R5;
    private Renderer R6;
    private Renderer R7;
    private Renderer R8;
    private Renderer R9;
    private Renderer R10;
    private Renderer R11;
    private Transform T0;
    private Transform T1;
    private Transform T2;
    private Transform T3;
    private Transform T4;
    private Transform T5;
    private Transform T6;
    private Transform T7;
    private Transform T8;
    private Transform T9;
    private Transform T10;
    private Transform T11;
    public bool OnPrepare;
    private bool ch;
    public bool IsFinish;
    public bool le;

    public int h, l, n;
    public int kh, kl;
    private int[,] a;
    private Text win;

    // Use this for initialization
    void Start () {
        OnPrepare = true;
        ch = true;
        IsFinish = false;
        a = new int[h, l];
        le = false;
        R0 = GameObject.Find("0").GetComponent<Renderer>();
        R1 = GameObject.Find("1").GetComponent<Renderer>();
        R2 = GameObject.Find("2").GetComponent<Renderer>();
        R3 = GameObject.Find("3").GetComponent<Renderer>();
        R4 = GameObject.Find("4").GetComponent<Renderer>();
        R5 = GameObject.Find("5").GetComponent<Renderer>();
        R6 = GameObject.Find("6").GetComponent<Renderer>();
        R7 = GameObject.Find("7").GetComponent<Renderer>();
        R8 = GameObject.Find("8").GetComponent<Renderer>();
        R9 = GameObject.Find("9").GetComponent<Renderer>();
        R10 = GameObject.Find("10").GetComponent<Renderer>();
        R11 = GameObject.Find("11").GetComponent<Renderer>();
        win = GameObject.Find("Canvas/Complete").GetComponent<Text>();
        T0 = R0.GetComponent<Transform>();
        T1 = R1.GetComponent<Transform>();
        T2 = R2.GetComponent<Transform>();
        T3 = R3.GetComponent<Transform>();
        T4 = R4.GetComponent<Transform>();
        T5 = R5.GetComponent<Transform>();
        T6 = R6.GetComponent<Transform>();
        T7 = R7.GetComponent<Transform>();
        T8 = R8.GetComponent<Transform>();
        T9 = R9.GetComponent<Transform>();
        T10 = R10.GetComponent<Transform>();
        T11 = R11.GetComponent<Transform>();

        R0.material.color = new Color(R0.material.color.r, R0.material.color.b, R0.material.color.g, 0);

        MakePuzzle();
        
        
    }
	
	// Update is called once per frame
	void Update () {
        if (OnPrepare)
        {
            if (le)
            {
                if (ch)
                {
                    ReSet();
                    ch = false;
                }
                R1.material.color += new Color(0, 0, 0, (float)0.01);
                R2.material.color += new Color(0, 0, 0, (float)0.01);
                R3.material.color += new Color(0, 0, 0, (float)0.01);
                R4.material.color += new Color(0, 0, 0, (float)0.01);
                R5.material.color += new Color(0, 0, 0, (float)0.01);
                R6.material.color += new Color(0, 0, 0, (float)0.01);
                R7.material.color += new Color(0, 0, 0, (float)0.01);
                R8.material.color += new Color(0, 0, 0, (float)0.01);
                R9.material.color += new Color(0, 0, 0, (float)0.01);
                R10.material.color += new Color(0, 0, 0, (float)0.01);
                R11.material.color += new Color(0, 0, 0, (float)0.01);
                if (R1.material.color.a >= 1)
                    OnPrepare = false;
            }
            else
            {
                //R0.material.color -= new Color(0, 0, 0, (float)0.01);
                R1.material.color -= new Color(0, 0, 0, (float)0.01);
                R2.material.color -= new Color(0, 0, 0, (float)0.01);
                R3.material.color -= new Color(0, 0, 0, (float)0.01);
                R4.material.color -= new Color(0, 0, 0, (float)0.01);
                R5.material.color -= new Color(0, 0, 0, (float)0.01);
                R6.material.color -= new Color(0, 0, 0, (float)0.01);
                R7.material.color -= new Color(0, 0, 0, (float)0.01);
                R8.material.color -= new Color(0, 0, 0, (float)0.01);
                R9.material.color -= new Color(0, 0, 0, (float)0.01);
                R10.material.color -= new Color(0, 0, 0, (float)0.01);
                R11.material.color -= new Color(0, 0, 0, (float)0.01);
                if (R1.material.color.a <= 0)
                    le = true;
            }
        }
        else
        {
            if (!IsFinish)
                if (T1.position.x == -3 && T1.position.y == 2)
                    if (T2.position.x == -1 && T2.position.y == 2)
                        if (T3.position.x == 1 && T3.position.y == 2)
                            if (T4.position.x == 3 && T4.position.y == 2)
                                if (T5.position.x == -3 && T5.position.y == 0)
                                    if (T6.position.x == -1 && T6.position.y == 0)
                                        if (T7.position.x == 1 && T7.position.y == 0)
                                            if (T8.position.x == 3 && T8.position.y == 0)
                                                if (T9.position.x == -3 && T9.position.y == -2)
                                                    if (T10.position.x == -1 && T10.position.y == -2)
                                                        if (T11.position.x == 3 && T11.position.y == -2)
                                                        {
                                                            IsFinish = true;
                                                            win.enabled = true;
                                                        }
            if(IsFinish)
                if (R0.material.color.a < 1)
                    R0.material.color += new Color(0, 0, 0, (float)0.01);

        }
	}

    private void MakePuzzle()
    {

        kh = n / l;
        kl = n % l;
        int i = 0;
        int last = 0, next;
        int o = 1, p, q;
        int[,] b = new int[h, l];
        for (p = 0; p < h; p++)
        {
            for (q = 0; q < l; q++)
            {
                if (p != kh || q != kl)
                {
                    a[p, q] = o;
                    o++;
                }
            }
        }
        while (i < 12)
        {
            next = Random.Range(1, 5);
            if (last + next != 5)
            {
                switch (next)
                {
                    case 1:
                        if (kl != l-1)
                        {
                            a[kh, kl] = a[kh, kl + 1];
                            kl++;
                            last = next;
                            if (b[kh, kl] == 0)
                            {
                                b[kh, kl] = 1;
                                i++;
                            }
                        }
                        break;
                    case 2:
                        if (kh != h-1)
                        {
                            a[kh, kl] = a[kh + 1, kl];
                            kh++;
                            last = next;
                            if (b[kh, kl] == 0)
                            {
                                b[kh, kl] = 1;
                                i++;
                            }
                        }
                        break;
                    case 3:
                        if (kh != 0)
                        {
                            a[kh, kl] = a[kh - 1, kl];
                            kh--;
                            last = next;
                            if (b[kh, kl] == 0)
                            {
                                b[kh, kl] = 1;
                                i++;
                            }
                        }
                        break;
                    case 4:
                        if (kl != 0)
                        {
                            a[kh, kl] = a[kh, kl - 1];
                            kl--;
                            last = next;
                            if (b[kh, kl] == 0)
                            {
                                b[kh, kl] = 1;
                                i++;
                            }
                        }
                        break;
                }
            }
        }
        a[kh, kl] = 0;
        
    }

    public void ReSet()
    {
        int p, q;
        for (p = 0; p < h; p++)
        {
            for (q = 0; q < l; q++)
            {
                switch (a[p, q])
                {
                    case 1: T1.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 2: T2.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 3: T3.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 4: T4.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 5: T5.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 6: T6.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 7: T7.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 8: T8.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 9: T9.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 10: T10.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                    case 11: T11.position = new Vector3(2 * q - 3, 2 - 2 * p, 0); break;
                }
            }
        }
    }
    
}
